from example_tester import ExampleTester

class Main:
    def __init__(self):
        self.tester = ExampleTester()

    def predict(self, X):
        self.tester.print_working_directory()
        return {"status": "Working"}
    
    
if __name__ == "__main__":
    tester = ExampleTester()
    tester.print_working_directory()